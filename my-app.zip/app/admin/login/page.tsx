// "use client";

// import { useState } from "react";
// import { useRouter, useSearchParams } from "next/navigation";
// import { Loader2, Lock } from "lucide-react";
// import { apiFetch, setToken } from "@/lib/api";

// export default function AdminLoginPage() {
//   const router = useRouter();
//   const params = useSearchParams();

//   // Only allow /admin/* paths as the destination
//   const rawNext = params.get("next");
//   const next =
//     rawNext && rawNext.startsWith("/admin") ? rawNext : "/admin/products";

//   const [email, setEmail] = useState("");
//   const [password, setPassword] = useState("");
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState("");

//   const submit = async (e: React.FormEvent) => {
//     e.preventDefault();
//     setLoading(true);
//     setError("");

//     try {
//       const data = await apiFetch<{
//         success?: boolean;
//         token?: string;
//       }>("/api/admin/login", {
//         method: "POST",
//         body: JSON.stringify({ email, password }),
//       });

//       // If backend returns a token, store it
//       if (data.token) {
//         setToken(data.token);
//       }

//       // Navigate to the admin destination
//       router.push(next);
//       router.refresh();
//     } catch (err: any) {
//       setError(err.message ?? "Login failed");
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
//       <div className="w-full max-w-sm">
//         <div className="text-center mb-8">
//           <div className="mx-auto h-12 w-12 rounded-xl bg-ink-900 grid place-items-center mb-4">
//             <Lock className="h-5 w-5 text-white" />
//           </div>
//           <h1 className="text-xl font-semibold text-ink-900">
//             Admin sign in
//           </h1>
//           <p className="text-sm text-ink-500 mt-1">
//             Restricted access — Dynamic Dost catalog
//           </p>
//         </div>

//         <form onSubmit={submit} className="space-y-4">
//           <label className="block">
//             <span className="text-sm font-medium text-ink-700">Email</span>
//             <input
//               type="email"
//               autoComplete="username"
//               required
//               value={email}
//               onChange={(e) => setEmail(e.target.value)}
//               className="input mt-1.5"
//               placeholder="admin@dynamicdost.com"
//             />
//           </label>

//           <label className="block">
//             <span className="text-sm font-medium text-ink-700">Password</span>
//             <input
//               type="password"
//               autoComplete="current-password"
//               required
//               value={password}
//               onChange={(e) => setPassword(e.target.value)}
//               className="input mt-1.5"
//             />
//           </label>

//           {error && (
//             <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
//               {error}
//             </div>
//           )}

//           <button
//             type="submit"
//             disabled={loading}
//             className="btn btn-primary btn-lg w-full"
//           >
//             {loading ? (
//               <>
//                 <Loader2 className="h-4 w-4 animate-spin" /> Signing in…
//               </>
//             ) : (
//               "Sign in"
//             )}
//           </button>
//         </form>

//         <p className="mt-6 text-center text-xs text-ink-400">
//           Session expires after 4 hours of inactivity.
//         </p>
//       </div>
//     </div>
//   );
// }
"use client";

import { Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Loader2, Lock } from "lucide-react";
import { apiFetch, setToken } from "@/lib/api";

/* ================================
   INNER COMPONENT (uses useSearchParams)
   ================================ */
function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();

  const rawNext = params.get("next");
  const next =
    rawNext && rawNext.startsWith("/admin") ? rawNext : "/admin/products";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    try {
      const data = await apiFetch<{
        success?: boolean;
        token?: string;
      }>("/api/admin/login", {
        method: "POST",
        body: JSON.stringify({ email, password }),
      });

      if (data.token) {
        setToken(data.token);
      }

      router.push(next);
      router.refresh();
    } catch (err: any) {
      setError(err.message ?? "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="w-full max-w-sm">
      <div className="text-center mb-8">
        <div className="mx-auto h-12 w-12 rounded-xl bg-ink-900 grid place-items-center mb-4">
          <Lock className="h-5 w-5 text-white" />
        </div>
        <h1 className="text-xl font-semibold text-ink-900">Admin sign in</h1>
        <p className="text-sm text-ink-500 mt-1">
          Restricted access — Dynamic Dost catalog
        </p>
      </div>

      <form onSubmit={submit} className="space-y-4">
        <label className="block">
          <span className="text-sm font-medium text-ink-700">Email</span>
          <input
            type="email"
            autoComplete="username"
            required
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className="input mt-1.5"
            placeholder="admin@dynamicdost.com"
          />
        </label>

        <label className="block">
          <span className="text-sm font-medium text-ink-700">Password</span>
          <input
            type="password"
            autoComplete="current-password"
            required
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className="input mt-1.5"
          />
        </label>

        {error && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-700">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          className="btn btn-primary btn-lg w-full"
        >
          {loading ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" /> Signing in…
            </>
          ) : (
            "Sign in"
          )}
        </button>
      </form>

      <p className="mt-6 text-center text-xs text-ink-400">
        Session expires after 4 hours of inactivity.
      </p>
    </div>
  );
}

/* ================================
   PAGE WRAPPER (Suspense boundary)
   ================================ */
export default function AdminLoginPage() {
  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-16">
      <Suspense
        fallback={
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="h-6 w-6 animate-spin text-brand-600" />
            <p className="text-sm text-ink-500">Loading…</p>
          </div>
        }
      >
        <LoginForm />
      </Suspense>
    </div>
  );
}